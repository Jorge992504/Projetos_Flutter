# node-server-websockets-chat

run ```npm init```
