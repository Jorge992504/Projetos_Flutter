package com.example.lesson_flutter_websocket

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
