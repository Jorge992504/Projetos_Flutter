class UserConfig {
  static const String name = 'Naga Mobile 1';
}
