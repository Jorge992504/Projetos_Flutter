package com.iqfareez.app_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
